﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Form : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        this.ListBox1.Items.Clear();
    }

    //this is our send button
    protected void Button2_Click(object sender, EventArgs e)
    {
        string temp = TextBox1.Text + TextBox2.Text;

        

        const string Path = @"C:\Users\Dan the man\Desktop\news.txt";

        FileInfo newsstuff = new FileInfo(Path);

        using (TextWriter textwritter = newsstuff.AppendText())
        {

            textwritter.WriteLine(temp);
            textwritter.Flush();
            textwritter.Close();
            
              
        
        }


    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

        



    }

    //this is our receive button
    protected void Button1_Click(object sender, EventArgs e)
    {
        const string Path = @"C:\Users\Dan the man\Desktop\news.txt";

        FileInfo newsstuff = new FileInfo(Path);
        using (StreamReader sRead = newsstuff.OpenText()) {

            while (!sRead.EndOfStream)
            {

                    ListBox1.Items.Add(sRead.ReadLine());

                    if (this.ListBox1.Items.Count == 10)
                    {
                        this.ListBox1.Items.RemoveAt(1);
                    
                    }

            }
            sRead.Close();
        }

    }
}